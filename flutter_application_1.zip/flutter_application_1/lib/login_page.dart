import 'package:flutter/material.dart';
import 'package:flutter_application_1/signup.dart';

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    //

    return Scaffold(
      body: Center(
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQb60j2rZ61GyXNUs7bZv2bIvD-iL6OOEqS5Q&usqp=CAU"),
              fit: BoxFit.cover,
            )
          ),
          child: Column(

            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              //Icon(Icons.favorite),

              Text('Please Log In'),
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: (
                    TextField(

                      decoration: InputDecoration(
                          prefixIcon: Icon(Icons.email),

                          labelStyle: TextStyle(
                            color: Colors.black54,
                            fontFamily: 'Montserrat',
                          ),

                          filled: true, fillColor: Color(0xFFEFEBE9),

                          border: OutlineInputBorder(
                            borderSide: BorderSide(color: Color(0xFFEFEBE9)),
                              borderRadius: BorderRadius.circular(20)
                          ),

                          hintText: 'Email',

                          contentPadding: EdgeInsets.all(18)),

                    )
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(18.0),
                child: (
                    TextField(
                  decoration: InputDecoration(
                      filled: true, fillColor: Color(0xFFEFEBE9),

                      prefixIcon: Icon(Icons.lock),

                      labelStyle: TextStyle(
                        color: Colors.black54,
                        fontFamily: 'Montserrat',
                      ),


                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)),
                      hintText: 'Password',
                      contentPadding: EdgeInsets.all(18)),
                )),
              ),

              ButtonTheme(

                child: ElevatedButton(
                  onPressed: () {

                  },
                  child: const Text('Sign In'),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 25, vertical: 5),
                      shape: StadiumBorder()
                  ),
                ),
              ),
              //TextButton(onPressed: () {}, child: const Text('Sign Up')),

              Text('----------------------------------------OR-------------------------------------------'),

              ButtonTheme(
                child: ElevatedButton(
                    onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => signup()));
                },
                    child: const Text('Sign Up'),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.lightGreen,
                      shape: StadiumBorder(),
                    )
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
