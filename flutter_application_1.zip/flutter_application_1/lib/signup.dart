import 'package:flutter/material.dart';

class signup extends StatefulWidget {
  @override
  signupState createState() => signupState();
}

class signupState extends State<signup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(


        child: Container(

          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQb60j2rZ61GyXNUs7bZv2bIvD-iL6OOEqS5Q&usqp=CAU"),
              fit: BoxFit.cover,
            )
          ),

          //color: Colors.lightGreen,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: TextField(

                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(100),
                    ),
                    labelText: 'Full Name',

                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(18.0),
                child: TextField(

                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(100),
                    ),
                    labelText: 'Username',
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(18.0),
                child: TextField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(100),
                    ),
                    labelText: 'Password',
                  ),
                ),
              ),
              
              Padding(
                padding: EdgeInsets.only(left: 10, right: 10),

                child: ElevatedButton(
                  onPressed: () {  },
                  child: const Text('Sign Up'),

                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
