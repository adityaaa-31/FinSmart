import 'package:flutter/material.dart';
import 'package:flutter_application_1/login_page.dart';

// ignore: unnecessary_new
// ignore: prefer_const_constructors
void main() {
  runApp(
    MaterialApp(
      home: MyApp(),
    ),
  );
}
